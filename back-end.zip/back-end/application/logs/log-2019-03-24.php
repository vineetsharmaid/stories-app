<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-24 06:54:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-03-24 06:54:41 --> Unable to connect to the database
ERROR - 2019-03-24 07:56:57 --> Severity: Notice --> Undefined property: stdClass::$password D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 174
ERROR - 2019-03-24 07:57:01 --> Severity: Notice --> Undefined property: stdClass::$password D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 183
ERROR - 2019-03-24 08:27:18 --> Severity: Notice --> Undefined property: stdClass::$username D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 173
ERROR - 2019-03-24 08:27:18 --> Severity: Notice --> Undefined property: stdClass::$password D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 174
ERROR - 2019-03-24 08:27:18 --> Severity: Notice --> Undefined property: stdClass::$username D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 178
ERROR - 2019-03-24 08:30:15 --> Severity: Notice --> Undefined property: stdClass::$firstName D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 147
ERROR - 2019-03-24 08:30:15 --> Severity: Notice --> Undefined property: stdClass::$lastName D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 148
ERROR - 2019-03-24 08:30:15 --> Severity: Notice --> Undefined property: stdClass::$username D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 149
ERROR - 2019-03-24 08:30:15 --> Severity: Notice --> Undefined property: stdClass::$photoUrl D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 151
ERROR - 2019-03-24 08:30:15 --> Query error: Column 'first_name' cannot be null - Invalid query: INSERT INTO `users` (`first_name`, `last_name`, `username`, `user_email`, `profile_pic`, `password`) VALUES (NULL, NULL, NULL, 'vineetsharmaid@gmail.com', NULL, 'test')
ERROR - 2019-03-24 08:34:29 --> Severity: Notice --> Undefined property: stdClass::$firstName D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 147
ERROR - 2019-03-24 08:34:29 --> Severity: Notice --> Undefined property: stdClass::$lastName D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 148
ERROR - 2019-03-24 08:34:29 --> Severity: Notice --> Undefined property: stdClass::$username D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 149

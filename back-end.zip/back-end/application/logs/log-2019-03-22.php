<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-22 10:28:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-03-22 10:28:31 --> Unable to connect to the database

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-06 22:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-06 22:19:02 --> Unable to connect to the database
ERROR - 2019-05-06 22:19:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-06 22:19:35 --> Unable to connect to the database
ERROR - 2019-05-06 22:19:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-06 22:19:50 --> Unable to connect to the database
ERROR - 2019-05-06 22:21:40 --> Severity: Notice --> Undefined property: stdClass::$status D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 307
ERROR - 2019-05-06 22:35:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-06 22:35:37 --> Unable to connect to the database
ERROR - 2019-05-06 22:35:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-06 22:35:38 --> Unable to connect to the database
ERROR - 2019-05-06 22:35:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-06 22:35:51 --> Unable to connect to the database

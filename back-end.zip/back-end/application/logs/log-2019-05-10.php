<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-10 12:29:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`stories`.`story_id` AND `points_allocation`.`selector` == 'story'
LEFT JOIN `fo' at line 3 - Invalid query: SELECT `points_allocation`.*, `stories`.`slug`, `answer_ka_question`.`slug` as `answer_slug`, `question`.`slug` as `question_slug`
FROM `points_allocation`
LEFT JOIN `stories` ON `points_allocation`.`selector_id` =`=` `stories`.`story_id` AND `points_allocation`.`selector` == 'story'
LEFT JOIN `forum_answers` ON `points_allocation`.`selector_id` =`=` `forum_answers`.`answer_id` AND `points_allocation`.`selector` == 'answer'
LEFT JOIN `forum_questions` as `answer_ka_question` ON `answer_ka_question`.`question_id` =`=` `forum_answers`.`question_id`
LEFT JOIN `forum_questions` as `question` ON `points_allocation`.`selector_id` =`=` `question`.`question_id` AND `points_allocation`.`selector` == 'question'
WHERE `user_id` = '10'
GROUP BY `points_allocation`.`point_id`
ORDER BY `points_allocation`.`created` DESC
ERROR - 2019-05-10 12:30:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`stories`.`story_id` AND `points_allocation`.`selector` == 'story'
LEFT JOIN `fo' at line 3 - Invalid query: SELECT `points_allocation`.*, `stories`.`slug`, `answer_ka_question`.`slug` as `answer_slug`, `question`.`slug` as `question_slug`
FROM `points_allocation`
LEFT JOIN `stories` ON `points_allocation`.`selector_id` =`=` `stories`.`story_id` AND `points_allocation`.`selector` == 'story'
LEFT JOIN `forum_answers` ON `points_allocation`.`selector_id` =`=` `forum_answers`.`answer_id` AND `points_allocation`.`selector` == 'answer'
LEFT JOIN `forum_questions` as `answer_ka_question` ON `answer_ka_question`.`question_id` =`=` `forum_answers`.`question_id`
LEFT JOIN `forum_questions` as `question` ON `points_allocation`.`selector_id` =`=` `question`.`question_id` AND `points_allocation`.`selector` == 'question'
WHERE `points_allocation`.`user_id` = '10'
GROUP BY `points_allocation`.`point_id`
ORDER BY `points_allocation`.`created` DESC
ERROR - 2019-05-10 13:06:29 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-10 13:09:58 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-10 13:12:33 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-10 13:13:01 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-10 14:40:44 --> Severity: Notice --> Undefined variable: limit D:\wamp64\www\stories-app\back-end\application\controllers\auth\Admin.php 1134
ERROR - 2019-05-10 14:40:44 --> Severity: Notice --> Undefined variable: offset D:\wamp64\www\stories-app\back-end\application\controllers\auth\Admin.php 1135
ERROR - 2019-05-10 14:41:26 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\wamp64\www\stories-app\back-end\application\controllers\auth\Admin.php 1134
ERROR - 2019-05-10 14:41:27 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\wamp64\www\stories-app\back-end\application\controllers\auth\Admin.php 1134
ERROR - 2019-05-10 14:41:27 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\wamp64\www\stories-app\back-end\application\controllers\auth\Admin.php 1134
ERROR - 2019-05-10 14:41:27 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\wamp64\www\stories-app\back-end\application\controllers\auth\Admin.php 1134
ERROR - 2019-05-10 14:47:24 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-10 15:51:00 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-10 16:27:19 --> Severity: Notice --> Undefined offset: 0 D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 491
ERROR - 2019-05-10 16:27:19 --> Severity: Notice --> Trying to get property of non-object D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 491
ERROR - 2019-05-10 18:08:49 --> Query error: Table 'asian_stories.flagged_by' doesn't exist - Invalid query: SELECT *
FROM `flagged_by`
WHERE `post_id` = '48'
AND `user_id` = '10'
ERROR - 2019-05-10 18:09:38 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `flagged_posts`
WHERE `post_id` = '48'
AND `user_id` = '10'
ERROR - 2019-05-10 18:39:45 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-10 20:52:53 --> Severity: Parsing Error --> syntax error, unexpected '$topic_data' (T_VARIABLE) D:\wamp64\www\stories-app\back-end\application\controllers\auth\Admin.php 452
ERROR - 2019-05-10 21:49:42 --> Severity: Notice --> Undefined index: logo D:\wamp64\www\stories-app\back-end\application\controllers\auth\Admin.php 450
ERROR - 2019-05-10 22:17:08 --> Severity: Notice --> Undefined variable: company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Admin.php 582

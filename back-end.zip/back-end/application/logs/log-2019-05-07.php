<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-07 19:36:47 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `companies` (`name`) VALUES (NULL)
ERROR - 2019-05-07 19:37:51 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `companies` (`name`) VALUES (NULL)

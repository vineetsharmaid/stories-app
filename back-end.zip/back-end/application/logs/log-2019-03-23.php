<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-23 08:34:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-03-23 08:34:24 --> Unable to connect to the database
ERROR - 2019-03-23 08:34:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-03-23 08:34:35 --> Unable to connect to the database
ERROR - 2019-03-23 08:34:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-03-23 08:34:36 --> Unable to connect to the database
ERROR - 2019-03-23 08:39:47 --> Severity: Parsing Error --> syntax error, unexpected ',' D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 186
ERROR - 2019-03-23 08:40:20 --> Severity: Parsing Error --> syntax error, unexpected ',' D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 186
ERROR - 2019-03-23 08:50:47 --> Severity: Notice --> Undefined variable: password D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 186
ERROR - 2019-03-23 09:02:50 --> Severity: Notice --> Undefined offset: 0 D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 178
ERROR - 2019-03-23 09:03:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 178
ERROR - 2019-03-23 09:11:49 --> Severity: Notice --> Undefined variable: message D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 201
ERROR - 2019-03-23 09:13:19 --> Severity: Notice --> Undefined variable: data D:\wamp64\www\stories-app\back-end\application\controllers\Api.php 187

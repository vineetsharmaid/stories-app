<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-08 11:21:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-08 11:21:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-08 11:21:15 --> Unable to connect to the database
ERROR - 2019-05-08 11:21:15 --> Unable to connect to the database
ERROR - 2019-05-08 11:21:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-08 11:21:20 --> Unable to connect to the database
ERROR - 2019-05-08 11:21:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-08 11:21:20 --> Unable to connect to the database
ERROR - 2019-05-08 11:23:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-08 11:23:27 --> Unable to connect to the database
ERROR - 2019-05-08 11:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-08 11:24:02 --> Unable to connect to the database
ERROR - 2019-05-08 12:20:38 --> Query error: Unknown column 'company' in 'field list' - Invalid query: INSERT INTO `users` (`first_name`, `last_name`, `username`, `user_type`, `status`, `user_email`, `company`, `profile_pic`, `password`) VALUES ('test', 'user', 'testuser', 'user', 1, 'testuser@yopmail.com', '1', '', '$2y$10$nCBv52AnhKaZzOcM4SSOSeyoSZFSAtZG.A6TCIlr9LgFzxYv9hauy')
ERROR - 2019-05-08 12:23:19 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:23:19 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:26:34 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:26:34 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:34:27 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:34:27 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:37:14 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:37:15 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:40:05 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:40:05 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:40:41 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:40:41 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:41:08 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:41:08 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:43:01 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:43:02 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:43:23 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:43:23 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:43:45 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:43:45 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:44:56 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:44:56 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:46:02 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:46:02 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:46:59 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:46:59 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:50:34 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:50:34 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:53:28 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:53:28 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:57:04 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:57:04 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:59:15 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 12:59:15 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:08:48 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:08:48 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:08:48 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:08:48 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:14:17 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:14:17 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:14:17 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:14:17 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:18:32 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:18:32 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:18:32 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:18:32 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:19:11 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:19:11 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:19:11 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:19:11 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:30:33 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:30:33 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:30:33 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:30:33 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:31:21 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:31:21 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:31:21 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:31:21 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:32:38 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:32:38 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:32:38 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:32:38 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:33:10 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:33:10 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:33:10 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:33:10 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:34:36 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:34:36 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:34:36 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:34:36 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:35:55 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:35:55 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:35:55 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:35:55 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:35:55 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:35:55 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:38:21 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:38:21 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:38:21 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:38:21 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:38:21 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:38:21 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:39:20 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:39:20 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:39:20 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:39:20 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:39:20 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:39:20 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:40:21 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:40:21 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:40:21 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:40:21 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:40:21 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:40:21 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:42:14 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:42:14 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:42:14 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:42:14 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:42:14 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:42:14 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:42:59 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:42:59 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:42:59 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:42:59 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:42:59 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:42:59 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:43:22 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:43:22 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:43:22 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:43:22 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:43:22 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:43:22 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:45:00 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:45:00 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:45:00 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:45:00 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:45:00 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:45:00 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:45:50 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:45:50 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:45:50 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:45:50 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:45:50 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:45:50 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:46:25 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:46:25 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:46:25 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:46:25 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:46:25 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:46:25 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:47:18 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:47:18 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:47:18 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:47:18 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:47:18 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:47:18 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:48:06 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:48:06 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:48:06 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 13:48:06 --> Severity: Notice --> Undefined property: stdClass::$company_id D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 454
ERROR - 2019-05-08 13:48:06 --> Severity: Notice --> Undefined property: stdClass::$have_company D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 455
ERROR - 2019-05-08 13:48:06 --> Severity: Notice --> Undefined property: stdClass::$type D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 456
ERROR - 2019-05-08 18:27:45 --> Query error: Duplicate entry '13-10' for key 'PRIMARY' - Invalid query: INSERT INTO `story_user_likes` (`story_id`, `user_id`) VALUES ('13', '10')
ERROR - 2019-05-08 18:31:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `stories`.`story_id` = '13'' at line 2 - Invalid query: SELECT `stories`.`author_id`
WHERE `stories`.`story_id` = '13'
ERROR - 2019-05-08 18:32:35 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\wamp64\www\stories-app\back-end\system\database\DB_driver.php 1471
ERROR - 2019-05-08 18:32:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO `points_allocation` (`user_id`, `points`, `milestone`, `activity`, `selector`, `selector_id`, `total_points`) VALUES ('10', 10, 10, 'likes', 'story', '13', )
ERROR - 2019-05-08 18:34:37 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\wamp64\www\stories-app\back-end\system\database\DB_driver.php 1471
ERROR - 2019-05-08 18:34:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: INSERT INTO `points_allocation` (`user_id`, `points`, `milestone`, `activity`, `selector`, `selector_id`, `total_points`) VALUES ('10', 10, 10, 'likes', 'story', '13', )

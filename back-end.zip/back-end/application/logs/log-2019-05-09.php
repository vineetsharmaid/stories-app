<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-09 12:11:14 --> Query error: Table 'asian_stories.forum_answer_comments' doesn't exist - Invalid query: SELECT `forum_answer_comments`.*, `users`.`first_name`, `users`.`last_name`, `users`.`username`, `forum_answers`.`subject` as `answer`, `forum_questions`.`title` as `question`, `forum_questions`.`slug`, `forum_questions`.`question_id`
FROM `forum_answer_comments`
JOIN `users` ON `users`.`user_id` = `forum_answer_comments`.`user_id`
JOIN `forum_answers` ON `forum_answers`.`answer_id` = `forum_answer_comments`.`answer_id`
JOIN `forum_questions` ON `forum_questions`.`question_id` = `forum_answers`.`question_id`
WHERE `approved` = '0'
GROUP BY `forum_answer_comments`.`comment_id`
ERROR - 2019-05-09 12:11:17 --> Query error: Table 'asian_stories.forum_answer_comments' doesn't exist - Invalid query: SELECT `forum_answer_comments`.*, `users`.`first_name`, `users`.`last_name`, `users`.`username`, `forum_answers`.`subject` as `answer`, `forum_questions`.`title` as `question`, `forum_questions`.`slug`, `forum_questions`.`question_id`
FROM `forum_answer_comments`
JOIN `users` ON `users`.`user_id` = `forum_answer_comments`.`user_id`
JOIN `forum_answers` ON `forum_answers`.`answer_id` = `forum_answer_comments`.`answer_id`
JOIN `forum_questions` ON `forum_questions`.`question_id` = `forum_answers`.`question_id`
WHERE `approved` = '1'
GROUP BY `forum_answer_comments`.`comment_id`
ERROR - 2019-05-09 12:11:18 --> Query error: Table 'asian_stories.forum_answer_comments' doesn't exist - Invalid query: SELECT `forum_answer_comments`.*, `users`.`first_name`, `users`.`last_name`, `users`.`username`, `forum_answers`.`subject` as `answer`, `forum_questions`.`title` as `question`, `forum_questions`.`slug`, `forum_questions`.`question_id`
FROM `forum_answer_comments`
JOIN `users` ON `users`.`user_id` = `forum_answer_comments`.`user_id`
JOIN `forum_answers` ON `forum_answers`.`answer_id` = `forum_answer_comments`.`answer_id`
JOIN `forum_questions` ON `forum_questions`.`question_id` = `forum_answers`.`question_id`
WHERE `approved` = '0'
GROUP BY `forum_answer_comments`.`comment_id`
ERROR - 2019-05-09 12:11:49 --> Query error: Table 'asian_stories.forum_answer_user_likes' doesn't exist - Invalid query: SELECT `forum_questions`.*, `users`.`first_name`, `users`.`last_name`, `users`.`username`, `users`.`profile_pic`, `forum_answers`.`created` as `answered_at`, `forum_answers`.`subject` as `answer`, `forum_answers`.`views`, `forum_answers`.`answer_id`, count(distinct forum_answer_user_likes.user_id) as likes, count(distinct current_user_like.user_id) as user_liked, GROUP_CONCAT(distinct topics.name ORDER BY topics.topic_id) as topics, GROUP_CONCAT(distinct topics.topic_id ORDER BY topics.topic_id) as topic_ids
FROM `forum_questions`
LEFT JOIN `forum_answers` ON `forum_answers`.`question_id` = `forum_questions`.`question_id`
LEFT JOIN `thread_topics` ON `thread_topics`.`thread_id` = `forum_questions`.`question_id`
LEFT JOIN `topics` ON `topics`.`topic_id` = `thread_topics`.`topic_id`
LEFT JOIN `forum_answer_user_likes` ON `forum_answer_user_likes`.`answer_id` = `forum_answers`.`answer_id`
LEFT JOIN `forum_answer_user_likes` as `current_user_like` ON `current_user_like`.`answer_id` = `forum_answers`.`answer_id` AND `current_user_like`.`user_id` = 8
LEFT JOIN `users` ON `users`.`user_id` = `forum_answers`.`author_id`
WHERE `forum_questions`.`status` = 1
GROUP BY `forum_questions`.`question_id`
 LIMIT 4
ERROR - 2019-05-09 12:11:49 --> Query error: Unknown column 'topics.icon_class' in 'where clause' - Invalid query: SELECT `topics`.*, count(forum_questions.question_id) as questions
FROM `topics`
LEFT JOIN `thread_topics` ON `thread_topics`.`topic_id` = `topics`.`topic_id`
JOIN `forum_questions` ON `forum_questions`.`question_id` = `thread_topics`.`thread_id`
WHERE `topics`.`icon_class` != ''
GROUP BY `topics`.`topic_id`
ORDER BY `questions` DESC
 LIMIT 12
ERROR - 2019-05-09 12:12:07 --> Query error: Table 'asian_stories.forum_answer_user_likes' doesn't exist - Invalid query: SELECT `forum_answers`.*, `users`.`first_name`, `users`.`last_name`, `users`.`username`, `users`.`profile_pic`, count(distinct forum_answer_user_likes.user_id) as likes, count(distinct current_user_like.user_id) as user_liked, count(distinct forum_answer_comments.comment_id) as comments_count
FROM `forum_answers`
LEFT JOIN `forum_answer_user_likes` ON `forum_answer_user_likes`.`answer_id` = `forum_answers`.`answer_id`
LEFT JOIN `forum_answer_user_likes` as `current_user_like` ON `current_user_like`.`answer_id` = `forum_answers`.`answer_id` AND `current_user_like`.`user_id` = 8
LEFT JOIN `forum_answer_comments` ON (`forum_answer_comments`.`answer_id` = `forum_answers`.`answer_id` AND `forum_answer_comments`.`approved` = 1) OR (`forum_answer_comments`.`answer_id` = `forum_answers`.`answer_id` AND `forum_answer_comments`.`user_id` = 8)
LEFT JOIN `users` ON `users`.`user_id` = `forum_answers`.`author_id`
WHERE `forum_answers`.`question_id` = '15'
AND `forum_answers`.`author_id` != '8'
GROUP BY `forum_answers`.`answer_id`
ORDER BY `likes` DESC
ERROR - 2019-05-09 12:12:11 --> Query error: Table 'asian_stories.forum_answer_user_likes' doesn't exist - Invalid query: SELECT `forum_questions`.*, `users`.`first_name`, `users`.`last_name`, `users`.`username`, `users`.`profile_pic`, `forum_answers`.`created` as `answered_at`, `forum_answers`.`subject` as `answer`, `forum_answers`.`views`, `forum_answers`.`answer_id`, count(distinct forum_answer_user_likes.user_id) as likes, count(distinct current_user_like.user_id) as user_liked, GROUP_CONCAT(distinct topics.name ORDER BY topics.topic_id) as topics, GROUP_CONCAT(distinct topics.topic_id ORDER BY topics.topic_id) as topic_ids
FROM `forum_questions`
LEFT JOIN `forum_answers` ON `forum_answers`.`question_id` = `forum_questions`.`question_id`
LEFT JOIN `thread_topics` ON `thread_topics`.`thread_id` = `forum_questions`.`question_id`
LEFT JOIN `topics` ON `topics`.`topic_id` = `thread_topics`.`topic_id`
LEFT JOIN `forum_answer_user_likes` ON `forum_answer_user_likes`.`answer_id` = `forum_answers`.`answer_id`
LEFT JOIN `forum_answer_user_likes` as `current_user_like` ON `current_user_like`.`answer_id` = `forum_answers`.`answer_id` AND `current_user_like`.`user_id` = 8
LEFT JOIN `users` ON `users`.`user_id` = `forum_answers`.`author_id`
WHERE `forum_questions`.`status` = 1
GROUP BY `forum_questions`.`question_id`
 LIMIT 4
ERROR - 2019-05-09 12:12:11 --> Query error: Unknown column 'topics.icon_class' in 'where clause' - Invalid query: SELECT `topics`.*, count(forum_questions.question_id) as questions
FROM `topics`
LEFT JOIN `thread_topics` ON `thread_topics`.`topic_id` = `topics`.`topic_id`
JOIN `forum_questions` ON `forum_questions`.`question_id` = `thread_topics`.`thread_id`
WHERE `topics`.`icon_class` != ''
GROUP BY `topics`.`topic_id`
ORDER BY `questions` DESC
 LIMIT 12
ERROR - 2019-05-09 12:12:18 --> Query error: Table 'asian_stories.forum_answer_user_likes' doesn't exist - Invalid query: SELECT `forum_answers`.*, `users`.`first_name`, `users`.`last_name`, `users`.`username`, `users`.`profile_pic`, count(distinct forum_answer_user_likes.user_id) as likes, count(distinct current_user_like.user_id) as user_liked, count(distinct forum_answer_comments.comment_id) as comments_count
FROM `forum_answers`
LEFT JOIN `forum_answer_user_likes` ON `forum_answer_user_likes`.`answer_id` = `forum_answers`.`answer_id`
LEFT JOIN `forum_answer_user_likes` as `current_user_like` ON `current_user_like`.`answer_id` = `forum_answers`.`answer_id` AND `current_user_like`.`user_id` = 8
LEFT JOIN `forum_answer_comments` ON (`forum_answer_comments`.`answer_id` = `forum_answers`.`answer_id` AND `forum_answer_comments`.`approved` = 1) OR (`forum_answer_comments`.`answer_id` = `forum_answers`.`answer_id` AND `forum_answer_comments`.`user_id` = 8)
LEFT JOIN `users` ON `users`.`user_id` = `forum_answers`.`author_id`
WHERE `forum_answers`.`question_id` = '15'
AND `forum_answers`.`author_id` != '8'
GROUP BY `forum_answers`.`answer_id`
ORDER BY `likes` DESC
ERROR - 2019-05-09 12:12:21 --> Query error: Unknown column 'topics.icon_class' in 'where clause' - Invalid query: SELECT `topics`.*, count(forum_questions.question_id) as questions
FROM `topics`
LEFT JOIN `thread_topics` ON `thread_topics`.`topic_id` = `topics`.`topic_id`
JOIN `forum_questions` ON `forum_questions`.`question_id` = `thread_topics`.`thread_id`
WHERE `topics`.`icon_class` != ''
GROUP BY `topics`.`topic_id`
ORDER BY `questions` DESC
 LIMIT 12
ERROR - 2019-05-09 12:12:22 --> Query error: Table 'asian_stories.forum_answer_user_likes' doesn't exist - Invalid query: SELECT `forum_questions`.*, `users`.`first_name`, `users`.`last_name`, `users`.`username`, `users`.`profile_pic`, `forum_answers`.`created` as `answered_at`, `forum_answers`.`subject` as `answer`, `forum_answers`.`views`, `forum_answers`.`answer_id`, count(distinct forum_answer_user_likes.user_id) as likes, count(distinct current_user_like.user_id) as user_liked, GROUP_CONCAT(distinct topics.name ORDER BY topics.topic_id) as topics, GROUP_CONCAT(distinct topics.topic_id ORDER BY topics.topic_id) as topic_ids
FROM `forum_questions`
LEFT JOIN `forum_answers` ON `forum_answers`.`question_id` = `forum_questions`.`question_id`
LEFT JOIN `thread_topics` ON `thread_topics`.`thread_id` = `forum_questions`.`question_id`
LEFT JOIN `topics` ON `topics`.`topic_id` = `thread_topics`.`topic_id`
LEFT JOIN `forum_answer_user_likes` ON `forum_answer_user_likes`.`answer_id` = `forum_answers`.`answer_id`
LEFT JOIN `forum_answer_user_likes` as `current_user_like` ON `current_user_like`.`answer_id` = `forum_answers`.`answer_id` AND `current_user_like`.`user_id` = 8
LEFT JOIN `users` ON `users`.`user_id` = `forum_answers`.`author_id`
WHERE `forum_questions`.`status` = 1
GROUP BY `forum_questions`.`question_id`
 LIMIT 4
ERROR - 2019-05-09 12:18:49 --> Query error: Table 'asian_stories.forum_answer_user_likes' doesn't exist - Invalid query: SELECT `forum_answers`.*, `users`.`first_name`, `users`.`last_name`, `users`.`username`, `users`.`profile_pic`, count(distinct forum_answer_user_likes.user_id) as likes, count(distinct current_user_like.user_id) as user_liked, count(distinct forum_answer_comments.comment_id) as comments_count
FROM `forum_answers`
LEFT JOIN `forum_answer_user_likes` ON `forum_answer_user_likes`.`answer_id` = `forum_answers`.`answer_id`
LEFT JOIN `forum_answer_user_likes` as `current_user_like` ON `current_user_like`.`answer_id` = `forum_answers`.`answer_id` AND `current_user_like`.`user_id` = 8
LEFT JOIN `forum_answer_comments` ON (`forum_answer_comments`.`answer_id` = `forum_answers`.`answer_id` AND `forum_answer_comments`.`approved` = 1) OR (`forum_answer_comments`.`answer_id` = `forum_answers`.`answer_id` AND `forum_answer_comments`.`user_id` = 8)
LEFT JOIN `users` ON `users`.`user_id` = `forum_answers`.`author_id`
WHERE `forum_answers`.`question_id` = '15'
AND `forum_answers`.`author_id` != '8'
GROUP BY `forum_answers`.`answer_id`
ORDER BY `likes` DESC
ERROR - 2019-05-09 12:18:51 --> Query error: Table 'asian_stories.forum_answer_user_likes' doesn't exist - Invalid query: SELECT `forum_questions`.*, `users`.`first_name`, `users`.`last_name`, `users`.`username`, `users`.`profile_pic`, `forum_answers`.`created` as `answered_at`, `forum_answers`.`subject` as `answer`, `forum_answers`.`views`, `forum_answers`.`answer_id`, count(distinct forum_answer_user_likes.user_id) as likes, count(distinct current_user_like.user_id) as user_liked, GROUP_CONCAT(distinct topics.name ORDER BY topics.topic_id) as topics, GROUP_CONCAT(distinct topics.topic_id ORDER BY topics.topic_id) as topic_ids
FROM `forum_questions`
LEFT JOIN `forum_answers` ON `forum_answers`.`question_id` = `forum_questions`.`question_id`
LEFT JOIN `thread_topics` ON `thread_topics`.`thread_id` = `forum_questions`.`question_id`
LEFT JOIN `topics` ON `topics`.`topic_id` = `thread_topics`.`topic_id`
LEFT JOIN `forum_answer_user_likes` ON `forum_answer_user_likes`.`answer_id` = `forum_answers`.`answer_id`
LEFT JOIN `forum_answer_user_likes` as `current_user_like` ON `current_user_like`.`answer_id` = `forum_answers`.`answer_id` AND `current_user_like`.`user_id` = 8
LEFT JOIN `users` ON `users`.`user_id` = `forum_answers`.`author_id`
WHERE `forum_questions`.`status` = 1
GROUP BY `forum_questions`.`question_id`
 LIMIT 4
ERROR - 2019-05-09 12:27:05 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 12:55:06 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 13:02:06 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 13:05:23 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 13:23:54 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 13:56:13 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 202
ERROR - 2019-05-09 13:56:30 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 202
ERROR - 2019-05-09 13:56:30 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 202
ERROR - 2019-05-09 13:56:34 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 202
ERROR - 2019-05-09 13:56:34 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 202
ERROR - 2019-05-09 13:56:42 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 202
ERROR - 2019-05-09 13:56:42 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 202
ERROR - 2019-05-09 13:58:28 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 13:58:31 --> Severity: Warning --> Creating default object from empty value D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 174
ERROR - 2019-05-09 13:58:31 --> Severity: Notice --> Object of class stdClass could not be converted to int D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 176
ERROR - 2019-05-09 13:58:31 --> Severity: Notice --> Object of class stdClass could not be converted to int D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 176
ERROR - 2019-05-09 13:58:32 --> Severity: Notice --> Trying to get property of non-object D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 1282
ERROR - 2019-05-09 13:58:32 --> Query error: Column 'total_points' cannot be null - Invalid query: INSERT INTO `points_allocation` (`user_id`, `points`, `milestone`, `activity`, `selector`, `selector_id`, `total_points`) VALUES ('10', 10, 10, 'likes', 'story', '12', NULL)
ERROR - 2019-05-09 13:58:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp64\www\stories-app\back-end\system\core\Exceptions.php:271) D:\wamp64\www\stories-app\back-end\system\core\Common.php 570
ERROR - 2019-05-09 13:59:25 --> Severity: Notice --> Trying to get property of non-object D:\wamp64\www\stories-app\back-end\application\controllers\auth\Users.php 1282
ERROR - 2019-05-09 13:59:25 --> Query error: Column 'total_points' cannot be null - Invalid query: INSERT INTO `points_allocation` (`user_id`, `points`, `milestone`, `activity`, `selector`, `selector_id`, `total_points`) VALUES ('10', 10, 10, 'likes', 'story', '12', NULL)
ERROR - 2019-05-09 14:00:35 --> Severity: Notice --> Undefined variable: user_points D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 176
ERROR - 2019-05-09 14:00:35 --> Severity: Notice --> Trying to get property of non-object D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 176
ERROR - 2019-05-09 14:00:35 --> Severity: Notice --> Undefined variable: user_points D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 179
ERROR - 2019-05-09 14:00:35 --> Severity: Notice --> Trying to get property of non-object D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 179
ERROR - 2019-05-09 14:00:35 --> Severity: Notice --> Undefined variable: user_points D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 182
ERROR - 2019-05-09 14:00:35 --> Severity: Notice --> Trying to get property of non-object D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 182
ERROR - 2019-05-09 14:00:35 --> Severity: Notice --> Undefined variable: user_points D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 185
ERROR - 2019-05-09 14:00:35 --> Severity: Notice --> Trying to get property of non-object D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 185
ERROR - 2019-05-09 14:00:35 --> Severity: Notice --> Undefined variable: user_points D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 188
ERROR - 2019-05-09 14:00:35 --> Severity: Notice --> Trying to get property of non-object D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 188
ERROR - 2019-05-09 14:00:35 --> Severity: Notice --> Undefined variable: user_points D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 191
ERROR - 2019-05-09 14:00:35 --> Severity: Notice --> Trying to get property of non-object D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 191
ERROR - 2019-05-09 14:00:35 --> Severity: Notice --> Undefined variable: badge D:\wamp64\www\stories-app\back-end\application\models\Common_model.php 197
ERROR - 2019-05-09 14:00:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp64\www\stories-app\back-end\system\core\Exceptions.php:271) D:\wamp64\www\stories-app\back-end\system\core\Common.php 570
ERROR - 2019-05-09 14:20:00 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 14:20:09 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 14:24:26 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 14:35:09 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 14:41:35 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 14:46:04 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 14:46:12 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 15:03:29 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 17:57:59 --> 404 Page Not Found: Assets/uploads
ERROR - 2019-05-09 17:58:49 --> 404 Page Not Found: Assets/uploads

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-27 13:23:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-27 13:23:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\wamp64\www\stories-app\back-end\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-04-27 13:23:37 --> Unable to connect to the database
ERROR - 2019-04-27 13:23:38 --> Unable to connect to the database
